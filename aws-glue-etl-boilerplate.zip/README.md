# 🚀 AWS Glue ETL Boilerplate (PySpark + Incremental + Logging)

A production-ready AWS Glue ETL boilerplate using **PySpark**, with:

✔ Logging framework  
✔ Bookmark-based incremental load  
✔ Partitioning best practices  
✔ Reusable utility functions  
✔ Local testing support  
✔ Templated config file  

---
